import * as Type from '../constants/movies.constant';

export function getAllMovies() {
    return {
        type: Type.GET_ALL_MOVIES,
    };
}

