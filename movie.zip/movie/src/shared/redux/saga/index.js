import { takeEvery, take, call, put, all } from 'redux-saga/effects';
import { moviesSaga } from './movies.saga';

//root saga
//single entry point to start sagas at once
export default function* rootSaga() {
    yield all([
	    moviesSaga(),
    ])
}
