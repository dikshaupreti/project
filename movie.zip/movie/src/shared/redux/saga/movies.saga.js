import {all, call, put, takeLatest, select} from 'redux-saga/effects';
import * as Type from '../constants/movies.constant';

function* getAllMovies(action) {
  try {
    yield put({type:'moviesLoading', payload:true});
    const response = yield fetch('https://api.jikan.moe/v3/search/anime?q=naruto')
        .then(response => response.json() );    
    console.log(response);
    yield put({
      type: Type.GET_MOVIES_SUCCESSFUL,
      payload: response.results,
    });
  } catch (e) {
    yield put({
      type: Type.GET_MOVIES_FAILURE,
      payload: e?.message,
    });
  }
  finally {
    yield put({type:'moviesLoading', payload:false}); 
  }
}

export function* moviesSaga() {
  yield all([
    takeLatest(Type.GET_ALL_MOVIES, getAllMovies),
  ]);
}


