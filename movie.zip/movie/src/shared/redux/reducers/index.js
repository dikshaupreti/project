import { combineReducers } from 'redux';
import moviesListing from './movies.reducer';



const rootReducer = combineReducers({
	moviesListing: moviesListing,
})

export default rootReducer;