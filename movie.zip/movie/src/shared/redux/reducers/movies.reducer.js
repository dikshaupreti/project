import * as Type from '../constants/movies.constant';
const initState = {movies: [], moviesLoading: false};

export default (state = initState, action) => {
    switch (action.type) {
        
        case Type.GET_MOVIES_SUCCESSFUL:
            return {...state, moviesData: action.payload}
        case 'moviesLoading':
            
            return {...state, moviesLoading: action.payload}
            default:
            return state;
    }
};
