import { render, fireEvent, screen } from "@testing-library/react";
import Movies from './index';

//test block
test("rendered movies component", () => {
    // render the component on virtual dom
    render(<Movies />);

    //select the elements you want to interact with
    const loading = screen.getByTestId("moviesContainer");

    //assert the expected result
    expect(loading).toBeTruthy();
});