import {render} from "@testing-library/react";
import MoviesListing from './index';

describe("Movies Component", () => {
    it("rendered movies listing component", () =>{
        const {getByTestId} = render(<MoviesListing />)
        const container = getByTestId("movielisting");
        expect(container).toBeTruthy();
     })
})