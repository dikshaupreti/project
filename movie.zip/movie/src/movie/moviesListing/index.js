import Grid from "@material-ui/core/Grid";

function MoviesListing(props) {
  return (
        <Grid item xs={2} md={2} lg={3} data-testid="movielisting">
            <img src={props.moviesDetails.image_url}/>
        </Grid>
  );
}

export default MoviesListing;
