import React from 'react';
import MoviesListing from './moviesListing/index';
import Grid from "@material-ui/core/Grid";
import { connect } from 'react-redux';
import { getAllMovies} from '../shared/redux/actions/movies.action';

class Movies extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      error: null,
      isLoaded: false,
      items: []
    };
  }

  componentDidMount() {
    this.props.getAllMovies();
    
  }

  render() {
    const { error, isLoaded, items } = this.state;
    if (error) {
      return <div data-testid="movieserror">Error: {error.message}</div>;
    } else if (!this.props.moviesLoading ) {
      return (
        <div style={{paddingTop: "63"}} >
          <h2 style={{textAlign: "center"}} data-testid="moviesListing">Movie Listing</h2>  
          <Grid container spacing={2}>
            {this.props.moviesData && this.props.moviesData.map(item => (
              <MoviesListing moviesDetails={item}/>
            ))}
          
          </Grid>
        </div>
      );
    }
    else {
      return <div data-testid="moviesContainer">Loading...</div>;
    } 
  }
}
const mapStateToProps = (state) => {
  
  return {
    moviesData: state?.moviesListing?.moviesData,
    moviesLoading:state?.moviesListing?.moviesLoading
  };
}

export default connect(mapStateToProps, {
  getAllMovies
})(Movies);