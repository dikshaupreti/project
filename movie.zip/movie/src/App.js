import logo from './logo.svg';
import './App.css';
import Movies from './movie/index'

function App() {
  return (
    <Movies />
  );
}

export default App;
