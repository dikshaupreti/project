// import { render, screen } from '@testing-library/react';
// import App from './App';
// import Movies from './movie/index'

// test('renders learn react link', () => {
//   render(<App />);
//   const linkElement = screen.getByText(/Loading/i);
//   expect(linkElement).toBeTruthy();
// });
